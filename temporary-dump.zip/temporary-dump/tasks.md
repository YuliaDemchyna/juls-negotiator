# PERSONAL CHECKLIST>>


[] ensure agent is using webhooks/tools correctly  



---

# Before demo

[] cover conversational edge cases, like user responses cases 


