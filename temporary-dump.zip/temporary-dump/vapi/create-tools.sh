#!/bin/bash

# Create/Update Vapi Tools for Debt Negotiation Agent
# These tools support the negotiation flow in your flowchart

VAPI_API_KEY="ea8c377d-c06b-406b-8dfd-39711ab9ee7d"
SERVER_URL="https://080dd9e7a75a.ngrok-free.app"

echo "Creating getUserInfo tool..."
curl -X POST "https://api.vapi.ai/tool" \
  -H "Authorization: Bearer $VAPI_API_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"type\": \"apiRequest\",
    \"apiRequest\": {
      \"name\": \"getUserInfo\",
      \"description\": \"Get user information including name and debt by phone number\",
      \"parameters\": {
        \"type\": \"object\",
        \"properties\": {
          \"phone_number\": { \"type\": \"string\", \"description\": \"Caller phone number in E.164\" }
        },
        \"required\": [\"phone_number\"]
      }
    },
    \"server\": {
      \"url\": \"$SERVER_URL/api/userinfo\",
      \"timeoutSeconds\": 20
    }
  }" | cat

echo -e "\n\nCreating negotiate tool..."
curl -X POST "https://api.vapi.ai/tool" \
  -H "Authorization: Bearer $VAPI_API_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"type\": \"apiRequest\",
    \"apiRequest\": {
      \"name\": \"negotiate\",
      \"description\": \"Negotiate debt repayment terms\",
      \"parameters\": {
        \"type\": \"object\",
        \"properties\": {
          \"phone_number\": { \"type\": \"string\" },
          \"user_debt\": { \"type\": \"number\" },
          \"user_amount\": { \"type\": \"number\" },
          \"user_amounts\": {
            \"type\": \"array\",
            \"items\": { \"type\": \"number\" }
          },
          \"agent_amounts\": {
            \"type\": \"array\",
            \"items\": { \"type\": \"number\" }
          }
        },
        \"required\": [\"phone_number\", \"user_debt\", \"user_amount\", \"user_amounts\", \"agent_amounts\"]
      }
    },
    \"server\": {
      \"url\": \"$SERVER_URL/api/negotiation\",
      \"timeoutSeconds\": 20
    }
  }" | cat

echo -e "\n\nCreating saveResult tool..."
curl -X POST "https://api.vapi.ai/tool" \
  -H "Authorization: Bearer $VAPI_API_KEY" \
  -H "Content-Type: application/json" \
  -d "{
    \"type\": \"function\",
    \"apiRequest\": {
      \"name\": \"saveResult\",
      \"description\": \"Save the outcome of the call\",
      \"parameters\": {
        \"type\": \"object\",
        \"properties\": {
          \"user_id\": { \"type\": \"string\" },
          \"status\": { \"type\": \"string\", \"enum\": [\"SUCCESS\",\"PARTIAL\",\"REFUSED\",\"STOP\"] },
          \"initial_amount\": { \"type\": \"number\" },
          \"final_amount\": { \"type\": \"number\" },
          \"debt\": { \"type\": \"number\" }
        },
        \"required\": [\"user_id\",\"status\",\"initial_amount\",\"final_amount\",\"debt\"]
      }
    },
    \"server\": {
      \"url\": \"$SERVER_URL/api/call_result\",
      \"timeoutSeconds\": 20
    }
  }" | cat

echo -e "\n\nAll tools created successfully!"