#!/bin/bash

# Setup Inbound Phone Number for Debt Collection Agent
# Customers will call this number and reach your agent

ASSISTANT_ID="f9d356ca-2af6-4dcd-bbd0-427d425ac99b"
VAPI_API_KEY="ea8c377d-c06b-406b-8dfd-39711ab9ee7d"

echo "Setting Up Inbound Phone Number"
echo "==============================="

echo -e "\nThis will create a phone number that customers can call."
echo "When a customer calls this number, your agent will:"
echo "1. Answer with a greeting"
echo "2. Automatically look up their account by phone number"
echo "3. Start the debt negotiation flow"
echo ""

# Option 1: Create a new phone number
echo -e "\n=== OPTION 1: Create New Phone Number ==="
read -p "Create a new inbound phone number? (y/n): " CREATE_NUMBER

if [ "$CREATE_NUMBER" = "y" ] || [ "$CREATE_NUMBER" = "Y" ]; then
  echo "Creating inbound phone number..."
  curl -X POST "https://api.vapi.ai/phone-number" \
    -H "Authorization: Bearer ${VAPI_API_KEY}" \
    -H "Content-Type: application/json" \
    -d "{
      \"assistantId\": \"${ASSISTANT_ID}\",
      \"provider\": \"twilio\",
      \"name\": \"Debt Collection Line\"
    }"
  echo -e "\n"
fi

# Option 2: List existing phone numbers
echo -e "\n=== OPTION 2: Use Existing Phone Number ==="
read -p "List your existing phone numbers? (y/n): " LIST_NUMBERS

if [ "$LIST_NUMBERS" = "y" ] || [ "$LIST_NUMBERS" = "Y" ]; then
  echo "Your existing phone numbers:"
  curl -s -X GET "https://api.vapi.ai/phone-number" \
    -H "Authorization: Bearer ${VAPI_API_KEY}" | jq '.[]' || echo "No phone numbers found"
  echo -e "\n"
  
  read -p "Enter phone number ID to update (or press Enter to skip): " PHONE_ID
  if [ ! -z "$PHONE_ID" ]; then
    echo "Updating phone number ${PHONE_ID} to use your assistant..."
    curl -X PATCH "https://api.vapi.ai/phone-number/${PHONE_ID}" \
      -H "Authorization: Bearer ${VAPI_API_KEY}" \
      -H "Content-Type: application/json" \
      -d "{
        \"assistantId\": \"${ASSISTANT_ID}\"
      }"
    echo -e "\n"
  fi
fi

# Option 3: Test with web call
echo -e "\n=== OPTION 3: Test with Web Call ==="
echo "For testing, you can simulate an inbound call using a web call:"
read -p "Start a test web call? (y/n): " START_WEB_CALL

if [ "$START_WEB_CALL" = "y" ] || [ "$START_WEB_CALL" = "Y" ]; then
  echo "Starting test web call..."
  curl -X POST "https://api.vapi.ai/call/web" \
    -H "Authorization: Bearer ${VAPI_API_KEY}" \
    -H "Content-Type: application/json" \
    -d "{
      \"assistantId\": \"${ASSISTANT_ID}\"
    }"
  echo -e "\n"
fi

echo -e "\n=== IMPORTANT NOTES ==="
echo "• Make sure your test phone numbers exist in your database"
echo "• The agent will automatically call getUserInfo() with the caller's phone number"
echo "• Test with phone numbers from your users table"
echo "• Monitor calls at: https://dashboard.vapi.ai/calls"
echo ""
echo "Your agent is now ready for inbound calls!"
