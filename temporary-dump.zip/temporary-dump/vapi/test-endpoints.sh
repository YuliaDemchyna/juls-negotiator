#!/bin/bash

# Test script to verify your backend endpoints work before testing with Vapi
SERVER_URL="https://080dd9e7a75a.ngrok-free.app"

echo "Testing Backend Endpoints"
echo "========================"

# Test 1: Health check
echo -e "\n1. Testing health endpoint..."
curl -s "${SERVER_URL}/api/health" | jq '.' || echo "Health check failed"

# Test 2: Test getUserInfo endpoint
echo -e "\n2. Testing getUserInfo endpoint..."
read -p "Enter a test phone number (e.g., +1234567890): " TEST_PHONE

if [ ! -z "$TEST_PHONE" ]; then
  echo "Testing with phone: $TEST_PHONE"
  curl -X POST "${SERVER_URL}/api/vapi/get-user-info" \
    -H "Content-Type: application/json" \
    -H "Authorization: Bearer test-vapi-token" \
    -d "{
      \"message\": {
        \"functionCall\": {
          \"parameters\": {
            \"phone_number\": \"${TEST_PHONE}\"
          }
        }
      }
    }" | jq '.' || echo "getUserInfo test failed"
fi

# Test 3: Test negotiation endpoint
echo -e "\n3. Testing negotiation endpoint..."
curl -X POST "${SERVER_URL}/api/vapi/negotiate" \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer test-vapi-token" \
  -d '{
    "message": {
      "functionCall": {
        "parameters": {
          "user_debt": 1000,
          "user_amount": 300,
          "user_amounts": [300],
          "agent_amounts": []
        }
      }
    }
  }' | jq '.' || echo "Negotiation test failed"

# Test 4: Check if server is accessible
echo -e "\n4. Testing server accessibility..."
curl -I "${SERVER_URL}" 2>/dev/null | head -1 || echo "Server not accessible"

echo -e "\n\nTesting complete!"
echo "If any tests failed, check:"
echo "- Is your server running?"
echo "- Is ngrok tunnel active?"
echo "- Are your database tables populated with test data?"
