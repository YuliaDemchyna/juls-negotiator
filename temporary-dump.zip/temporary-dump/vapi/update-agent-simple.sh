#!/bin/bash

# Simple agent update with working configuration
ASSISTANT_ID="f9d356ca-2af6-4dcd-bbd0-427d425ac99b"
VAPI_API_KEY="ea8c377d-c06b-406b-8dfd-39711ab9ee7d"
SERVER_URL="https://080dd9e7a75a.ngrok-free.app"

echo "Updating agent for inbound calls..."

curl -X PATCH "https://api.vapi.ai/assistant/${ASSISTANT_ID}" \
  -H "Authorization: Bearer ${VAPI_API_KEY}" \
  -H "Content-Type: application/json" \
  -d @- << 'EOF'
{
  "name": "Juls Debt Negotiation Agent - Inbound",
  "firstMessage": "Hello! You've reached Juls Collectors. Please hold while I look up your account information.",
  "voice": {
    "model": "eleven_turbo_v2_5",
    "speed": 1,
    "voiceId": "21m00Tcm4TlvDq8ikWAM",
    "provider": "11labs",
    "stability": 0.5,
    "similarityBoost": 0.75,
    "enableSsmlParsing": true,
    "optimizeStreamingLatency": 3
  },
  "functions": [
    {
      "name": "getUserInfo",
      "description": "Get user information including name and debt amount",
      "parameters": {
        "type": "object",
        "properties": {
          "phone_number": {
            "description": "The phone number of the caller",
            "type": "string"
          }
        },
        "required": ["phone_number"]
      },
      "serverUrl": "https://080dd9e7a75a.ngrok-free.app/api/vapi/get-user-info"
    },
    {
      "name": "negotiatePayment",
      "description": "Calculate negotiation response based on user payment offer",
      "parameters": {
        "type": "object",
        "properties": {
          "user_debt": {
            "description": "Total user debt",
            "type": "number"
          },
          "user_amount": {
            "description": "Current user offer amount",
            "type": "number"
          },
          "user_amounts": {
            "description": "History of user offers",
            "type": "array",
            "items": {"type": "number"}
          },
          "agent_amounts": {
            "description": "History of agent counter-offers",
            "type": "array",
            "items": {"type": "number"}
          }
        },
        "required": ["user_amounts", "agent_amounts", "user_amount", "user_debt"]
      },
      "serverUrl": "https://080dd9e7a75a.ngrok-free.app/api/vapi/negotiate"
    },
    {
      "name": "saveCallResult",
      "description": "Save the final call result and trigger post-call workflows",
      "parameters": {
        "type": "object",
        "properties": {
          "debt": {
            "description": "Total debt amount",
            "type": "number"
          },
          "status": {
            "description": "Call outcome status",
            "type": "string",
            "enum": ["SUCCESS", "PARTIAL", "REFUSED"]
          },
          "user_id": {
            "description": "User ID from getUserInfo",
            "type": "string"
          },
          "final_amount": {
            "description": "Final agreed amount, 0 if refused",
            "type": "number"
          },
          "phone_number": {
            "description": "User phone number",
            "type": "string"
          },
          "initial_amount": {
            "description": "Initial amount offered by user",
            "type": "number"
          }
        },
        "required": ["user_id", "phone_number", "status", "initial_amount", "final_amount", "debt"]
      },
      "serverUrl": "https://080dd9e7a75a.ngrok-free.app/api/vapi/save-result"
    }
  ],
  "model": {
    "model": "gpt-4-turbo",
    "messages": [
      {
        "role": "system",
        "content": "You are a professional debt collection agent for INBOUND calls. Follow this flow: 1) IMMEDIATELY call getUserInfo with caller phone number 2) Greet with account info 3) When they offer payment, call negotiatePayment 4) If HAGGLE status, continue negotiating up to 3 rounds 5) When STOP status or they accept, call saveCallResult 6) End appropriately. Always be professional and empathetic."
      }
    ],
    "provider": "openai",
    "maxTokens": 500,
    "temperature": 0.7,
    "numFastTurns": 1,
    "emotionRecognitionEnabled": true
  },
  "endCallMessage": "Thank you for your time today. Have a good one!",
  "transcriber": {
    "model": "nova-2",
    "language": "en",
    "provider": "deepgram"
  },
  "serverUrl": "https://mflsmdlfe.com",
  "endCallPhrases": [
    "goodbye",
    "bye bye", 
    "end call",
    "hang up",
    "I'm done",
    "stop calling"
  ],
  "server": {
    "url": "https://mflsmdlfe.com",
    "timeoutSeconds": 20
  }
}
EOF

echo ""
echo "Agent updated successfully!"
